# FingerPainter
MDP coursework1
This is code for my MDP cw1.
ALL of this are my work so DO NOT COPY ANY OF THE CODE!
I push on the moodle because I lose the first version of my coursework,and this is my Second Try.

The cw is about develop a fingerpainter App. Really simple, only test the transaction between activities.
